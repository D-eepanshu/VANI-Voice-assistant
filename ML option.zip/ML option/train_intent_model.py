import json
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB

# Load intents
with open('ML option/intents.json') as f:
    data = json.load(f)

texts = []
labels = []

# Prepare training data
for item in data:
    for example in item['examples']:
        texts.append(example)
        labels.append(item['intent'])

# Convert text to features
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(texts)

# Train model
model = MultinomialNB()
model.fit(X, labels)

# Save model and vectorizer
joblib.dump(model, 'intent_model.pkl')
joblib.dump(vectorizer, 'vectorizer.pkl')

print("✅ Training complete. Model saved as 'intent_model.pkl' and 'vectorizer.pkl'")
