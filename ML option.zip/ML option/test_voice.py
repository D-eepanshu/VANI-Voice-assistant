import pyttsx3

# Initialize the pyttsx3 engine
engine = pyttsx3.init()

# Get the list of voices available on the system
voices = engine.getProperty('voices')

# List all available voices
for index, voice in enumerate(voices):
    print(f"Voice {index}:")
    print(f" - Name: {voice.name}")
    print(f" - ID: {voice.id}")
    print(f" - Languages: {voice.languages}")
    print(f" - Gender: {voice.gender}")
    print(f" - Age: {voice.age}")
    print("")
